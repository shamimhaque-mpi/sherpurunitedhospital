<style type="text/css">
    .profile-title{display: flex;}
    .profile-title img{
        width: 70px;
        height: 70px;
        margin-bottom:  10px;
    }

    @media print{
        aside, nav, .none, .panel-heading, .panel-footer{ display: none !important;}
        .panel{
            border: 1px solid transparent;
            left: 0px;
            position: absolute;
            top: 0px;
            width: 100%;
        }
        .hide{display: block !important;}
        .photo {
            position: relative;
        }
        .photo .profile-pic {
            position: absolute;
            top: 215px;
            left: 15px;

        }
        .margin_left {
            margin-left: 50%;
        }
    }  
</style>


<div class="container-fluid">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="panal-header-title pull-left">
                    <h1>Employee's Profile</h1>
                </div>
            </div>

            <div class="panel-body">
                

                <div class="row">
                    <!-- left side -->
                    <div class="col-xs-3 photo">
                        <figure class="profile-pic">
                            <div class="border-top">&nbsp;</div>
                            <img style="margin-bottom: 0;" src="<?php echo site_url($emp_info[0]->path); ?>" alt="" class="img-responsive">
                        </figure>
                        <br/>
                    </div>

                    <div class="col-md-9">
                        <!-- Print banner -->
                        <img class="img-responsive hide" src="<?php echo site_url('private/images/banner.jpg'); ?>" alt="" style="width: 100%; height: 120px;">
                       <span class="hide print-time"><?php echo filter($this->data['name']) . ' | ' . date('Y, F j  h:i a'); ?></span>
                        
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs none" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Profile</a>
                            </li>
                        </ul>

                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="profile">
                                <div class="row profile-title no-padding">
                                    <div class="col-xs-6">
                                        <div class="profile-title">
                                            <h3 class="pull-left img-show" style="margin-bottom: 20px;"> <?php echo filter($emp_info[0]->name); ?> </h3>
                                        </div>
                                    </div>


                                    <div class="col-xs-6">
                                        <?php foreach ($emp_info as $key => $emp) { ?>
                                        <a class="pull-right none" style="width: 60px;" href="<?php echo site_url('employee/employee/edit_employee?id='.$emp->id) ;?>">  <i class="fa fa-pencil"></i>&nbsp; Edit </a>
                                        <a class="pull-right none" href="#" onclick="window.print()" style="width: 60px; background: #46C35F; margin-right: 5px;"><i class="fa fa-print" aria-hidden="true"></i>&nbsp; Print </a>
                                        <?php } ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-xs-6 margin-left hide">&nbsp;</div>
                                    <div class="col-xs-6 col-xs-12 no-padding margin_left">
                                        <label class="control-label col-xs-5">Employee ID</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->emp_id; ?></p>
                                        </div>
                                    </div>

                                    <div class="col-xs-6 col-xs-12 no-padding margin_left">
                                        <label class="control-label col-xs-5">Joining Date</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->joining_date; ?></p>
                                        </div>
                                    </div>

                                    <div class="col-xs-6 col-xs-12 no-padding margin_left">
                                       <label class="control-label col-xs-5">Father's Name</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->father_name; ?></p>
                                        </div>
                                    </div>

                                    <div class="col-xs-6 col-xs-12 no-padding margin_left">
                                       <label class="control-label col-xs-5">Mother's Name</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->mother_name; ?></p>
                                        </div>
                                    </div>

                                    <div class="col-xs-6 col-xs-12 no-padding margin_left">
                                        <label class="control-label col-xs-5">Gender</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->gender; ?></p>
                                        </div>
                                    </div>

                                    <div class="col-xs-6 col-xs-12 no-padding margin_left">
                                        <label class="control-label col-xs-5">Date Of Birth</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->date_of_birth; ?></p>
                                        </div>
                                    </div>

                                    <div class="col-xs-6 col-xs-12 no-padding margin_left">
                                        <label class="control-label col-xs-5">Mobile Number</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->mobile; ?></p>
                                        </div>
                                    </div>

                                    <div class="col-xs-6 col-xs-12 no-padding">
                                        <label class="control-label col-xs-5">Email</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->email; ?></p>
                                        </div>
                                    </div>

                                    <div class="col-xs-6 col-xs-12 no-padding">
                                        <label class="control-label col-xs-5">NID no.</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->nid_no; ?></p>
                                        </div>
                                    </div>


                                    <div class="col-xs-6 col-xs-12 no-padding">
                                        <label class="control-label col-xs-5">Designation</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->designation; ?></p>
                                        </div>
                                    </div>


                                    <div class="col-xs-6 col-xs-12 no-padding">
                                        <label class="control-label col-xs-5">Present Address</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->present_address; ?></p>
                                        </div>
                                    </div>


                                    <div class="col-xs-6 col-xs-12 no-padding">
                                        <label class="control-label col-xs-5">Permanent Address</label>
                                        <div class="col-xs-7">
                                             <p><?php echo $emp_info[0]->permanent_address; ?></p>
                                        </div>
                                    </div>


                                    <div class="col-xs-6 col-xs-12 no-padding">
                                        <label class="control-label col-xs-5">Remarks</label>
                                        <div class="col-xs-7">
                                            <p><?php echo $emp_info[0]->remarks; ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="panel-footer">&nbsp;</div>
        </div>
    </div>
</div>