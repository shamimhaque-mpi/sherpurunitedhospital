<div class="container-fluid">
    <div class="row">
<?php //echo "<pre>"; print_r($emp_info); echo "</pre>"; ?>
<?php echo $confirmation; ?>

        <div class="panel panel-default">
            <div class="panel-heading panal-header">
                <div class="panal-header-title pull-left">
                    <h1>Edit</h1>
                </div>
            </div>

            <div class="panel-body">
                <?php
                $attr=array( "class"=>"form-horizontal" );
                echo form_open_multipart("employee/employee/edit_employee?id=".$this->input->get("id"),$attr);
                ?>
                
                    <div class="form-group">
                        <label class="col-md-2 control-label">&nbsp; </label>
                        <div class="col-md-5">
                            <img src="<?php echo base_url($emp_info[0]->path); ?>" width="120px" alt="">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Employee ID </label>
                        <div class="col-md-5">
                            <input type="text" name="emp_id" value="<?php echo $emp_info[0]->emp_id; ?>" class="form-control" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Employee Name </label>
                        <div class="col-md-5">
                            <input type="text" name="full_name" value="<?php echo $emp_info[0]->name; ?>" class="form-control" >
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Father’s Name </label>
                        <div class="col-md-5">
                            <input type="text" name="father_name" value="<?php echo $emp_info[0]->father_name; ?>" class="form-control" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label">Mother’s Name </label>
                        <div class="col-md-5">
                            <input type="text" name="mother_name" value="<?php echo $emp_info[0]->mother_name; ?>" class="form-control" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label">Gender </label>
                        <div class="col-md-5">
                            <label class="radio-inline">
                                <input type="radio" name="gender" value="Male" <?php if($emp_info[0]->gender =="Male"){ echo "checked"; } ?> > Male 
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="gender" value="Female" <?php if($emp_info[0]->gender =="Female"){ echo "checked"; } ?> > Female
                            </label>
                        </div>
                    </div>

                     <div class="form-group">
                        <label class="col-md-2 control-label"> Date Of Birth </label>
                        <div class="input-group date col-md-5" id="datetimepicker1">
                            <input type="text" name="date_of_birth" value="<?php echo $emp_info[0]->date_of_birth; ?>" class="form-control" >
                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Mobile Number </label>
                        <div class="col-md-5">
                            <input type="text" name="mobile_number" value="<?php echo $emp_info[0]->mobile; ?>" class="form-control" >
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="col-md-2 control-label">Email </label>
                        <div class="col-md-5">
                            <input type="text" name="email" value="<?php echo $emp_info[0]->email; ?>" class="form-control" >
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label"> Joining Date </label>
                        <div class="input-group date col-md-5" id="datetimepicker1">
                            <input type="text" name="joining_date" value="<?php echo $emp_info[0]->joining_date; ?>" class="form-control" >
                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">NID No </label>
                        <div class="col-md-5">
                            <input type="text" name="nid_no" value="<?php echo $emp_info[0]->nid_no; ?>" class="form-control" >
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Present Address </label>
                        <div class="col-md-5">
                            <textarea name="present_address" id="pre_addr" class="form-control" cols="30" rows="5" ><?php echo $emp_info[0]->present_address; ?></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Permanent Address</label>
                        <div class="col-md-5">
                            <input type="checkbox" id="permanent_address" value="0"> <label for="permanent_address">Same As Present Address </label>
                            <textarea name="permanent_address" id="per_addr" class="form-control" cols="30" rows="5" ><?php echo $emp_info[0]->permanent_address; ?></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Designation</label>
                        <div class="col-md-5" >
                            <select name="designation" class="form-control" >
                                <option value="">-- Select Your Option --</option>
                                <?php foreach (config_item('desigation') as $value) { ?>
                                    <option value="<?php echo $value; ?>" <?php if($emp_info[0]->designation == $value){ echo "selected"; } ?> ><?php echo $value; ?></option>
                                <?php } ?>

                            </select>
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="col-md-2 control-label">Remarks</label>
                        <div class="col-md-5">
                            <textarea name="remarks" class="form-control" cols="30" rows="5" ><?php echo $emp_info[0]->remarks; ?></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Photo  </label>
                        <div class="col-md-5">
                            <input id="input-test" type="file" name="attachFile" class="form-control file" data-show-preview="true" data-show-upload="true" data-show-remove="true">
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="btn-group pull-right">
                            <input type="submit" name="update_emp" value="Update " class="btn btn-success">
                        </div>
                    </div>

                <?php echo form_close(); ?>
            </div>
            <div class="panel-footer">&nbsp;</div>
        </div>
    </div>
</div>
