<style>
    @media print{
        aside, nav, .none, .panel-heading, .panel-footer{
            display: none !important;
        }
        .panel{
            border: 1px solid transparent;
            left: 0px;
            position: absolute;
            top: 0px;
            width: 100%;
        }
        .hide{
            display: block !important;
        }

    }
     .print-banner{
            width: 100%;
            height: 120px;
        }
</style>

<div class="container-fluid">
    <div class="row">
        <?php echo $this->session->flashdata('confirmation'); ?>

        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="panal-header-title ">
                    <h1 class="pull-left"> All Employee  <br>  <small><?php echo count($emp_info)?> Item Found</small></h1>
                    <a class="btn btn-primery pull-right" style="font-size: 14px; margin-top: 0;" onclick="window.print()"><i class="fa fa-print"></i> Print</a>
                </div>
            </div>

            <div class="panel-body">

                <!-- Print Banner -->
                <img class="img-responsive hide print-banner" src="<?php echo site_url('private/images/banner.jpg'); ?>">

                <h4 class="text-center hide" style="margin-top: -10px;">All Employee </h4>
                <span class="hide print-time"><?php echo filter($this->data['name']) . ' | ' . date('Y, F j  h:i a'); ?></span>

                <table class="table table-bordered">
                    <tr>
                        <th width="40">SL</th>
                        <th>ID</th>
                        <th>Joining Date</th>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>NID No</th>
                        <th>Designation</th>
                        <th>Mobile No</th>
                        <th class="none">Action</th>
                    </tr>

                    <?php foreach ($emp_info as $key => $emp) { ?>
                    <tr>
                        <td> <?php echo $key+1; ?> </td>
                        <td class="text-center"> <?php echo $emp->emp_id; ?> </td>
                        <td style="width: 130px;"> <?php echo $emp->joining_date; ?> </td>
                        <td style="width: 50px;"> <img src="<?php echo site_url($emp->path); ?>" width="40px" height="40px" alt="" style="object-fit: cover;"></td>
                        <td> <?php echo filter($emp->name); ?> </td>
                        <td> <?php echo filter($emp->nid_no); ?> </td>
                        <td> <?php echo filter(str_replace("_"," ", $emp->designation)); ?></td>
                        <td> <?php echo $emp->mobile; ?></td>
                        <td class="none" style="width: 150px;">
                            <div class="dropdown">
                                
                                <?php if(ck_action("employee_menu","view")){ ?>
                                <a title="Edit" class="btn btn-warning" href="<?php echo site_url('employee/employee/profile?id='.$emp->id);?>" ><i class="fa fa-eye" aria-hidden="true"></i></a>
                                <?php } ?>                                

                                <?php if(ck_action("employee_menu","edit")){ ?>
                                <a class="btn btn-info" href="<?php echo site_url('employee/employee/edit_employee?id='.$emp->id) ;?>"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                <?php } ?>                                

                                <?php if(ck_action("employee_menu","delete")){ ?>
                                <a title="Delete" class="btn btn-danger" onclick="return confirm('Do you want to delete this Category?');" href="<?php echo site_url('/employee/employee/delete/'.$emp->id) ;?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                <?php } ?>                            

                            </div>
                        </td>
                    </tr>
                    <?php } ?>
                </table>

            </div>

            <div class="panel-footer">&nbsp;</div>
        </div>
    </div>
</div>
