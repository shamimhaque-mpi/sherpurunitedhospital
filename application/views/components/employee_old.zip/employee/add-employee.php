<div class="container-fluid">
    <div class="row">
    <?php echo $confirmation;
     ?>
        <div class="panel panel-default">

            <div class="panel-heading panal-header">
                <div class="panal-header-title pull-left">
                    <h1>
                        <?php //echo caption('Add_Employee') ;?>
                       New Employee 
                    </h1>
                </div>
            </div>

            <div class="panel-body">
            
                <!-- horizontal form -->
                <?php
                    $attr=array("class"=>"form-horizontal");
                    echo form_open_multipart('', $attr);
                ?>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Employee ID </label>
                        <div class="col-md-5">
                            <input type="text" name="emp_id" class="form-control" value="<?php echo $emp_id;?>"  readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Employee Name </label>
                        <div class="col-md-5">
                            <input type="text" name="full_name" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Father’s Name </label>
                        <div class="col-md-5">
                            <input type="text" name="father_name" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label">Mother’s Name </label>
                        <div class="col-md-5">
                            <input type="text" name="mother_name" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label">Gender </label>
                        <div class="col-md-5">
                            <label class="radio-inline">
                                <input type="radio" name="gender" value="Male" checked> Male 
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="gender" value="Female" > Female
                            </label>
                        </div>
                    </div>

                     <div class="form-group">
                        <label class="col-md-2 control-label"> Date Of Birth </label>
                        <div class="input-group date col-md-5" id="datetimepicker1">
                            <input type="text" name="date_of_birth" class="form-control">
                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Mobile Number </label>
                        <div class="col-md-5">
                            <input type="text" name="mobile_number" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Email </label>
                        <div class="col-md-5">
                            <input type="email" name="email" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label"> Joining Date </label>
                        <div class="input-group date col-md-5" id="datetimepicker2">
                            <input type="text" name="joining_date" class="form-control">
                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">NID No </label>
                        <div class="col-md-5">
                            <input type="text" name="nid_no" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Present Address </label>
                        <div class="col-md-5">
                            <textarea name="present_address" id="pre_addr" class="form-control" cols="30" rows="5"></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Permanent Address<span class="req">*</span></label>
                        <div class="col-md-5">
                            <input type="checkbox" id="permanent_address" value="0"> <label for="permanent_address">Same As Present Address </label>
                            <textarea name="permanent_address" id="per_addr" class="form-control" cols="30" rows="5"></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-2 control-label">Designation </label>
                        <div class="col-md-5" >
                            <select name="designation" class="selectpicker form-control" data-show-subtext="true" data-live-search="true">
                                <option value="" selected disabled>-- Select Your Option --</option>
                                <?php foreach (config_item('desigation') as $value) { ?>
                                    <option value="<?php echo $value; ?>"><?php echo $value; ?></option>
                                <?php } ?>

                            </select>
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="col-md-2 control-label">Remarks</label>
                        <div class="col-md-5">
                            <textarea name="remarks"  class="form-control" cols="30" rows="5" ></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-2 control-label">Photo </label>
                        <div class="col-md-5">
                            <input id="input-test" type="file" name="attachFile" class="form-control file" data-show-preview="false" data-show-upload="false" data-show-remove="false">
                        </div>
                    </div>
                    
                    <div class="col-md-7">
                        <div class="btn-group pull-right">
                            <input type="submit" name="add_emp" value="Save" class="btn btn-primary">
                        </div>
                    </div>

                <?php echo form_close(); ?>

            </div>

            <div class="panel-footer">&nbsp;</div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $(".teachers_option").hide();
        $(".staff_option").hide();
        $("select#teacher_type").on("change", function(){
            if($(this).val() == "staff"){
                $(".teachers_option").fadeOut('slow');
                $(".staff_option").fadeIn('slow');
                $(".staff_option").show();
            }
            else{
                $(".teachers_option").fadeIn('slow');
                $(".teachers_option").show();
                $(".staff_option").fadeOut('slow');
            }

        });
        $('#datetimepicker2').datetimepicker({
            format: 'YYYY-MM-DD',
            useCurrent: false
        });
        $("#permanent_address").on("click",function(){
            if ($(this).is(":checked")) {
                $("#per_addr").val($("#pre_addr").val());
            }
            else{
                $("#per_addr").val("");
            }
        });
    });
</script>
